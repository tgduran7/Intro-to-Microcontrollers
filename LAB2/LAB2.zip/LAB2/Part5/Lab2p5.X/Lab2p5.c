#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <math.h>
#include <p18f4620.h>

#pragma config OSC = INTIO67
#pragma config WDT = OFF
#pragma config LVP = OFF
#pragma config BOREN = OFF

void Delay_One_Sec();

void main()
{
    char in;            // Use variable ?in? as char
    char L2;
    char L3;
    
    
    //TRISA = 0xFF;       // fill out the ?? with the proper values, input
    TRISC = 0x00;
    TRISD = 0x00;
    
    ADCON1 = 0x0F;      // fill out the ?? with the proper values
    
    char L2_array[8] = {0x01, 0x07, 0x03, 0x04, 0x02, 0x06, 0x05, 0x00};
    char L3_array[8] = {0x04, 0x06, 0x02, 0x03, 0x00, 0x07, 0x05, 0x01};
    
    for (int I=0; I<=7; I++){
        
        
        L2 = L2_array[I];
        L3 = L3_array[I];
        L3 = L3 << 5;
        in = L2 | L3;
        
        PORTC = I;
        PORTD = in;
        
        Delay_One_Sec();
    }
    
}

void Delay_One_Sec()
{
    for(int I=0; I <17000; I++);
}
