void interrupt high_priority chkisr(void) ;
void T0_ISR();
void INT0_isr(void);
void TIMER1_isr(void);
void force_nec_state0();