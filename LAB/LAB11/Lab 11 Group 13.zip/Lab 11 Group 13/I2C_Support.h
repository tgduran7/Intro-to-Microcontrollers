void DS1621_Init(void);
void DS3231_Read_Time(void);
void DS3231_Setup_Time(void);
int DS1621_Read_Temp(void);
